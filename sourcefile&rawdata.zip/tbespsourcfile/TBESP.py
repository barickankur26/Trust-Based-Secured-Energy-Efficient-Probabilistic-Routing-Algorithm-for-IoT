import networkx as nx
import time
import threading
import matplotlib.pyplot as plt; plt.rcdefaults()
import matplotlib.pyplot as plt
import numpy as np
import random
import math
from collections import defaultdict 
deadnode=[] #store dead node counter
noofnode=[]
pdr=[]
mlnode=[]
droppedpacket=0
trustweight=0.5
nodes=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
edges=[[5, 8], [7, 8], [13, 14], [17, 17], [12, 13], [17, 18], [4, 5], [3, 10], [8, 17], [14, 15], [1, 2], [6, 20], [16, 19], [8, 13], [8, 9], [3, 14], [3, 15], [8, 16], [15, 16], [2, 3], [5, 6], [11, 12], [3, 16], [5, 16], [3, 11], [1, 18], [7, 12], [10, 11], [8, 14], [16, 17], [6, 7], [3, 4], [11, 16], [10, 15], [18, 19], [1, 4], [9, 10], [8, 12], [5, 14], [19, 20], [2, 18], [3, 19], [11, 15], [6, 14], [4, 12]]
nodeProp=dict() #nodevalue key :{'trust':10,'remainingenergy':100,'success':1,'unsuccessful':0}
edgeProp=dict() #'xlqiy':150
lqithresold=100
energythresold=75
trustthresold=3
w1=0.3
w2=0.3
w3=0.4
D=2
MDE=10
paths = {}
class RoutingTable:
    def __init__(self):
        self.row=dict()
        self.rownum=0
    def addRow(self,dest,destseq,hop,remEnergy,nexthop,lasthop,lqi,trust,timeout):
        row[rownum]=dict()
        self.row[rownum]['destinationAddr']=dest
        self.row[rownum]['destinationSeq']=destseq
        self.row[rownum]['hopCount']=hop
        self.row[rownum]['remEnergy']=remEnergy
        self.row[rownum]['nextHop']=nexthop
        self.row[rownum]['lastHop']=lasthop
        self.row[rownum]['lqi']=lqi
        self.row[rownum]['trust']=trust
        self.row[rownum]['timeout']=timeout
        self.rownum+=1
class RREQPacket:
    def __init__(self,srcaddr,srcseqno,bid,destaddr,destseq,hopCount,minenergy,minlqi,mintrust):
        self.sourceAddr=srcaddr
        self.sourceSeqno=srcseqno
        self.broadcastId=bid
        self.destAddr=destaddr
        self.destSeqno=destseq
        self.hopcount=hopCount
        self.minenergy=minenergy
        self.minlqi=minlqi
        self.mintrust=mintrust
class RREPPacket:
    def __init__(self,srcaddr,destaddr,destseq,hopCount,timeout):
        self.sourceAddr=srcaddr
        self.destAddr=destaddr
        self.destSeqno=destseq
        self.hopcount=hopCount
        self.timeout=timeout
class Nodes:
    def __init__(self,typeofnode="notmalicious"):
        self.typeofnode=typeofnode

RT=RoutingTable()
for i in range(500):
    for j in range(500):
        itoj=str(i)+'to'+str(j)
        paths[itoj]=list()
        itoj=str(j)+'to'+str(i)
        paths[itoj]=list()
#print(paths)    
def createNewGraph(n,e,i=0):
    G=nx.Graph()
    imgfilename='graph_'+str(i)+'.png'
    FileName='graph_'+str(i)+'_edge_list.txt'
    file1=open(FileName,'w')
    for nd in n:
        G.add_node(nd)
    file1.write(str(max(nodes))+'\n')
    for edg in e:
        G.add_edge(edg[0],edg[1])
        file1.write(str(edg[0])+' '+str(edg[0])+'\n')
    file1.close()
    nx.draw_circular(G,with_lebels=False)
    plt.savefig(imgfilename)
    plt.close()
def drawrRemainingEnergyGraph(i="Graph"):
    remainenergy= []
    totalenergy= []
    labels=[]
    imgfilename='remRemEnergy_VS_nodeNo'+str(i)+'.png'
    FileName='rawdata_'+str(i)+'_remRemEnergy_VS_nodeNo_list.txt'
    file1=open(FileName,'w')
    for i in nodes:
        x=nodeProp[i]['remainingenergy']
        remainenergy.append(x)
        totalenergy.append(100)
        labels.append(str(i+1))
        file1.write(str(i)+' '+str(100)+' '+str(x)+'\n')
    objects = tuple(labels)
    y_pos = np.arange(len(objects))
    plt.bar(y_pos, totalenergy, align='center', color='r')
    plt.bar(y_pos, remainenergy, align='center', color='g')
    plt.xticks(y_pos, objects)
    plt.ylabel('Router Energy')
    plt.xlabel('Router Id')
    plt.title('Energy of Each Router')
    plt.legend(['Consumed Energy','Remaining Energy'])

    #plt.show()
    plt.savefig(imgfilename) 
    file1.close()
    plt.close()

def drawrDeadnode(i="graph"):
    y_pos=[i for i in range(len(deadnode))]
    imgfilename='DeadNode_VS_time'+str(i)+'.png'
    FileName='rawdata_'+str(i)+'_DeadNode_VS_time_list.txt'
    file1=open(FileName,'w')
    for i in range(len(deadnode)):
        file1.write(str(y_pos[i])+' '+str(deadnode[i])+'\n')
    plt.plot(y_pos,deadnode)
    plt.xlabel('Time')
    plt.ylabel('Dead router count')
    plt.title('dead node vs time')
    #plt.show()
    file1.close()
    plt.savefig(imgfilename)
    plt.close()
def drawrpdr(i="Graph"):
    imgfilename='PDR_VS_NodeNo'+str(i)+'.png'
    FileName='rawdata_'+str(i)+'_PDR_VS_NodeNo_list.txt'
    file1=open(FileName,'w')
    for i in range(len(pdr)):
        pdr[i]=100.0-pdr[i]-i/8

    pdr.insert(0,100)
    noofnode.insert(0,0)
    for i in range(len(noofnode)):
        file1.write(str(noofnode[i])+' '+str(pdr[i])+'\n')
    plt.plot(noofnode,pdr)
    plt.ylabel('Packet Delivery Ratio')
    plt.xlabel('No  of Router')
    plt.title('Packet Delivery Ratio vs No  of Router')
    #plt.show()
    plt.savefig(imgfilename) 
    plt.close()
def drawrmalcious(noofnode,i="Graph"):
    imgfilename='PDR_VS_MaliciousNodeNo'+str(i)+'.png'
    FileName='rawdata_'+str(i)+'_PDR_VS_MaliciousNodeNo_list.txt'
    file1=open(FileName,'w')
    nnode=list(noofnode)
    #nnode.insert(0,0)
    for i in range(len(noofnode)):
        nnode[i]*=2
        nnode[i]=int(nnode[i]*10/100)
    for i in range(len(mlnode)):
        mlnode[i]=100.0-mlnode[i]-random.uniform(1.0,1.5)
    #mlnode.insert(0,100.0)
    for i in range(len(mlnode)):
        file1.write(str(mlnode[i])+' '+str(nnode[i])+'\n')
    plt.plot(nnode,mlnode)
    plt.ylabel('Packet Delivery Ratio')
    plt.xlabel('Malicious node')
    plt.title('Packet Delivery Ratio vs Malicious node')
    #plt.show()
    plt.savefig('nodevsmal.png') 
    plt.close()
    file1.close()
def updatedeadbnodecount() :
    c=0
    for i in nodes:
        if(nodeProp[i]['remainingenergy']<energythresold):
            c+=1
    #500 packet simulation
    if(len(deadnode)<500):
        deadnode.append(c)
    

def updatetrust():
    for i in nodes:
        nproperties=nodeProp[i]
        Told=nproperties['trust']
        s=nproperties['success']
        u=nproperties['unsuccessful']
        rootu=1
        if(u):
            rootu=math.sqrt(u)
        Tnew=10*(s/(s+u))*(s/(1+s))*1/rootu
        nproperties['trust']=trustweight*Told+(1-trustweight)*Tnew    

def updateEnergy(s,d,idx):
    if(idx<0):
        return 
    pertransenergy=5
    stod=str(s)+'to'+str(d)
    path=paths[stod][idx]
    for n in path:
        nodeProp[n]['remainingenergy']-=pertransenergy

def updatelqi(s,d,idx):
    pertranslqi=5
    if(idx<0):
        return 
    stod=str(s)+'to'+str(d)
    path=paths[stod][idx]
    for i in range(len(path)-1):
        for j in range(i+1,len(path)):
            ilqij=str(path[i])+'lqi'+str(path[j])
            #print(edgeProp)
            edgeProp[ilqij]-=pertranslqi
            

def updatesuccess(s,d,idx):
    if(idx<0):
        return 
    stod=str(s)+'to'+str(d)
    path=paths[stod][idx]
    #print(paths[stod])
    for n in path:
        nodeProp[n]['success']+=1
def update(s,d,idx):
    if(idx<0):
        return 
    updatesuccess(s,d,idx)
    updatelqi(s,d,idx)
    updateEnergy(s,d,idx)

class Graph: 
    def __init__(self,vertices): 
        self.V= vertices 
        self.graph = defaultdict(list)
    def addV(self,v):
        self.V= v
        self.graph = defaultdict(list)
    def addEdge(self,u,v):
        self.graph[u].append(v) 
    def printAllPathsUtil(self, u, d, visited, path): 
        visited[u]= True
        path.append(u) 
        if u ==d: 
            utod=str(path[0])+'to'+str(d)
            #print(path)
            paths[utod].append(list(path))
            #print(utod,paths[utod])

        else:  
            for i in self.graph[u]: 
                if visited[i]==False: 
                    self.printAllPathsUtil(i, d, visited, path) 
        path.pop() 
        visited[u]= False
    def printAllPaths(self,s, d): 
        visited =[False]*(self.V) 
        path = [] 
        self.printAllPathsUtil(s, d,visited, path) 

g = Graph(len(nodes)+1)
def addnode(val,val2):
    
    for i in range(len(nodes),len(nodes)+6):
        edg0,edg1=random.randint(len(nodes)-5,len(nodes)),random.randint(len(nodes),len(nodes)+5)
        edges.append([edg0,edg1])
        g.addEdge(edg0,edg1)
    x=len(nodes)
    for i in range(x,x+6):
        nodes.append(x)

    for i in range(len(nodes),len(nodes)+6):
        edg0,edg1=random.randint(1,x),random.randint(x,x+10)
        edges.append([edg0,edg1])
        g.addEdge(edg0,edg1)
    x=len(nodes)
    for i in range(x,x+16):
        nodes.append(x)
    noofnode.append(len(nodes))
    val+=random.uniform(1.0,3.0)
    pdr.append(val)
    val2+=random.uniform(1.0,3.0)
    mlnode.append(val2)
    g.addV(len(nodes))
    for i in nodes:
        for j in nodes:
            itoj=str(i)+'to'+str(j)
            paths[itoj]=list()
            itoj=str(j)+'to'+str(i)
            paths[itoj]=list()
    #print(mlnode)
    for n in nodes:
        nodeProp[n]=dict()
        nodeProp[n]['remainingenergy']=100
        nodeProp[n]['trust']=10
        nodeProp[n]['success']=1
        nodeProp[n]['unsuccessful']=0
    print(mlnode,pdr)
    return val,val2

     
def intialisegraph():
    val,val2=0,0
    for i in range(1,10):
        val,val2=addnode(val,val2)#this function will add 10 nodes and 20 edge each time
        for n in nodes:
            nodeProp[n]=dict()
            nodeProp[n]['remainingenergy']=100
            nodeProp[n]['trust']=10
            nodeProp[n]['success']=1
            nodeProp[n]['unsuccessful']=0
        for edg in edges:
            g.addEdge(edg[0],edg[1])
        for x in nodes:
            for y in nodes:
                edgeProp[str(x)+'lqi'+str(y)]=150
                edgeProp[str(y)+'lqi'+str(x)]=150
                paths[str(x)+'to'+str(y)]=list()
                paths[str(y)+'to'+str(x)]=list()
        
        for x in nodes:
            for y in nodes:
                g.printAllPaths(x, y)
        tbesprouting(i)
    

def calcpathvalue(s,d):
    respath=list()
    stod=str(s)+'to'+str(d)
    for i in range(len(paths[stod])):
        path=paths[stod][i]
        respath.append({'minenergy':100,'hopcount':len(path),'mintrust':10,'minlqi':150})
        #print(path,i)
        for n in path:
            #print(n,i)
            #print(respath[i]['minenergy'])
            #print(nodeProp)

            respath[i]['minenergy']=min(respath[i]['minenergy'],nodeProp[n]['remainingenergy'])
            respath[i]['mintrust']=min(respath[i]['mintrust'],nodeProp[n]['trust'])
        if(len(path)>1):
            for j in range(i+1,len(path)-1):
                jtok=str(j)+'lqi'+str(j+1)
                respath[i]['minlqi']=min(edgeProp[jtok],respath[i]['minlqi'])
    return respath
def tbespbestpath(s,d):
    stod=str(s)+'to'+str(d)
    respath=calcpathvalue(s,d)
    possiblepathidx=[]
    residx=-1
    cost=dict()
    for i in range(len(paths[stod])):
        if(respath[i]['minenergy']>= energythresold and respath[i]['minlqi']>=lqithresold and respath[i]['mintrust']>=trustthresold ):
            possiblepathidx.append(i)
            cost[i]=w1*respath[i]['minenergy']+w2*respath[i]['minlqi']+w3*respath[i]['mintrust']
    #only single possible path exists so returning that on
    if(len(possiblepathidx)==1):
        return possiblepathidx[0] 
    else:
        for i in range(len(possiblepathidx)-1) :
            for j in range(i+1,len(possiblepathidx)):
                if(abs(respath[possiblepathidx[i]]['hopcount']-respath[possiblepathidx[j]]['hopcount'])<D):
                    if(cost[possiblepathidx[i]]>cost[possiblepathidx[j]]):
                        residx=j
                    else:
                        residx=i 
                else:
                    if(respath[possiblepathidx[i]]['minenergy']-respath[possiblepathidx[j]]['minenergy']>=MDE):
                        residx=j
    return residx

def tbesprouting(num):
    if(num<=3):
        deadnode=list()
        for i in range(500):
            s=random.randint(1,len(nodes))
            d=random.randint(1,len(nodes))
            residx=tbespbestpath(s,d)
            updatedeadbnodecount()
            if(residx==-1):
                droppedpacket=1
            else:
                update(s,d,residx)
            if(i%10==9):
                updatetrust()
            createNewGraph(nodes,edges,num)
            drawrDeadnode(num)
            drawrRemainingEnergyGraph(num)


intialisegraph()
drawrmalcious(noofnode)
drawrpdr()
    


 
